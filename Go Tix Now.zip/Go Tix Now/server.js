require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const open = require("open").default;

const app = express();
const PORT = process.env.PORT || 3000;

// ✅ Middleware
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Serve Static Files (Frontend)
app.use(express.static(path.join(__dirname, 'frontend')));

// ✅ MongoDB Connection

mongoose.connect("mongodb://127.0.0.1:27017/project", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("MongoDB Connection Error:", err));


// ✅ User Schema & Model
const userSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  phone: { type: String, unique: true, required: true },
  password: { type: String, required: true }
});
const User = mongoose.model("User", userSchema);

// ✅ Booking Schema & Model

const bookingSchema = new mongoose.Schema({
  from: String,
  to: String,
  date: String,
  time: String,
  busType: String,
  operator: String,
  gender: String,
  seatNumbers: [Number]
});

const Booking = mongoose.model("Booking", bookingSchema);

// ✅ Serve Login Page (Root Route)
app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "frontend", "login.html");
  console.log("✅ Attempting to serve:", filePath);
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      console.error("❌ File not found:", filePath);
      return res.status(404).send("Login Page Not Found");
    }
    res.sendFile(filePath);
  });
});

// ✅ User Registration
app.post("/register", async (req, res) => {
  console.log("🛠 Received Registration Data:", req.body);
  const { firstName, lastName, email, phone, password } = req.body;

  if (!firstName || !lastName || !email || !phone || !password) {
    console.log("❌ Missing Fields");
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.log("⚠️ Email Already Exists");
      return res.status(400).json({ error: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ firstName, lastName, email, phone, password: hashedPassword });
    await newUser.save();

    console.log("✅ User Registered:", newUser);
    res.status(201).json({ message: "User Registered Successfully" });

  } catch (err) {
    console.error("❌ Registration Error:", err);
    res.status(500).json({ error: "User registration failed" });
  }
});

// ✅ User Login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ error: "User not found" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.json({ token, user });
});

// ✅ Create Bus Booking
app.use(express.json()); // Ensure Express can parse JSON

app.post("/api/book-bus", async (req, res) => {
  try {
    console.log("Received Data:", req.body);  // Debugging log
    const booking = new Booking(req.body);
    await booking.save();
    res.status(201).json({ message: "Booking Successful!", booking });
  } catch (err) {
    console.error("Booking Error:", err);
    res.status(500).json({ error: "Booking failed" });
  }
});


// ✅ Get All Bookings
app.get("/api/bookings", async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.status(200).json(bookings);
  } catch (error) {
    res.status(500).json({ message: "Error fetching bookings", error });
  }
});

// ✅ Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  open(`http://localhost:${PORT}/`);
});
